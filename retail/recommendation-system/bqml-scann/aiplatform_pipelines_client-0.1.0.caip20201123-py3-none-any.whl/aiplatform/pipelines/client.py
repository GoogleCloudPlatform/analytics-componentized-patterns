# Copyright 2020 Google LLC. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Module for AIPlatformPipelines API client."""

import datetime
import json
import re
import subprocess
from typing import Any, Dict, Mapping, Optional

from absl import logging
from googleapiclient import discovery

from google import auth
from google.auth import exceptions
from google.oauth2 import credentials
from aiplatform.pipelines import runtime_config_builder

# Client version. This is also referenced in setup.py
__version__ = '0.1.0.caip20201123'

# AIPlatformPipelines API endpoint.
DEFAULT_ENDPOINT = 'us-central1-aiplatform.googleapis.com'

# AIPlatformPipelines API version.
API_VERSION = 'v1alpha1'

# AIPlatformPipelines API visibility.
VISIBILITY_LABEL = 'PIPELINE_TRUSTED_TESTER'

# If application default credential does not exist, we fall back to whatever
# previously provided to `gcloud auth`. One can run `gcloud auth login` to
# provide identity for this token.
_AUTH_ARGS = ('gcloud', 'auth', 'print-access-token')

# AIPlatformPipelines service API job name relative name prefix pattern.
_JOB_NAME_PATTERN = ('projects/{project_id}/locations/{region}/'
                     'pipelineJobs/{job_name}')

# Pattern for valid names used as a uCAIP resource name.
_VALID_NAME_PATTERN = re.compile('^[a-z][-a-z0-9]{0,127}$')

# Cloud Console UI link of a pipeline run.
UI_PIPELINE_JOB_LINK_FORMAT = (
    'https://console.cloud.google.com/ai/platform/pipelines/runs/{}?'
    'e=CaipPipelinesAlphaLaunch::CaipPipelinesAlphaEnabled,'
    'BackendzOverridingLaunch::BackendzOverridingEnabled,'
    'CloudAiLaunch::CloudAiEnabled&project={}')

# Display UI link HTML snippet
UI_LINK_HTML_FORMAT = (
    'See the Pipeline job <a href="{}" target="_blank" >here</a>.')


class _AccessTokenCredentials(credentials.Credentials):
  """Credential class to provide token-based authentication."""

  def __init__(self, token):
    super().__init__(token=token)

  def refresh(self, request):
    # Overrides refresh method in the base class because by default token is
    # not refreshable.
    pass


def _get_gcp_credential() -> Optional[credentials.Credentials]:
  """Returns the GCP OAuth2 credential.

  Returns:
    The credential. By default the function returns the current Application
    Default Credentials, which is located at $GOOGLE_APPLICATION_CREDENTIALS. If
    not set, this function returns the current login credential, whose token is
    created by running 'gcloud auth login'.
    For more information, see
    https://cloud.google.com/sdk/gcloud/reference/auth/application-default/print-access-token
  """
  result = None
  try:
    result, _ = auth.default()
  except exceptions.DefaultCredentialsError as e:
    logging.warning(
        'Failed to get GCP access token for application '
        'default credential: (%s). Using end user credential.', e)
    try:
      token = subprocess.check_output(_AUTH_ARGS).rstrip().decode('utf-8')
      result = _AccessTokenCredentials(token=token)
    except subprocess.CalledProcessError as e:
      # _AccessTokenCredentials won't throw CalledProcessError, so this
      # exception implies that the subprocess call is failed.
      logging.warning('Failed to get GCP access token: %s', e)
  else:
    return result


def _get_current_time() -> datetime.datetime:
  """Gets the current timestamp."""
  return datetime.datetime.now()


def _is_ipython() -> bool:
  """Returns whether we are running in notebook."""
  try:
    import IPython  # pylint: disable=g-import-not-at-top
    ipy = IPython.get_ipython()
    if ipy is None:
      return False
  except ImportError:
    return False

  return True


def _extract_job_id(job_name: str) -> Optional[str]:
  """Extracts job id from job name.

  Args:
   job_name: The full job name.

  Returns:
   The job id or None if no match found.
  """
  p = re.compile(
      'projects/(?P<project_id>.*)/locations/(?P<region>.*)/pipelineJobs/(?P<job_id>.*)'
  )
  result = p.search(job_name)
  return result.group('job_id') if result else None


class Client(object):
  """AIPlatformPipelines Unified API Client."""

  def __init__(self,
               project_id: str,
               region: str,
               api_key: str,
               endpoint: Optional[str] = None,
               service_name: Optional[str] = None):
    """Constructs an AIPlatformPipelines API client.

    Args:
      project_id: GCP project ID.
      region: GCP project region.
      api_key: API key to access the AIPlatformPipelines endpoint. Please refer
        to [here](https://developers.google.com/places/web-service/get-api-key)
          regarding how to create one. Only API key associated with whitelisted
          GCP project can access AIPlatformPipelines service before its launch.
      endpoint: AIPlatformPipelines service endpoint. Defaults to
        'us-central1-aiplatform.googleapis.com'.
      service_name: AIPlatformPipelines service name. This is only applicable
        when endpoint is specified.
    """
    if not project_id:
      raise ValueError('A valid GCP project ID is required to run a pipeline.')
    if not region:
      raise ValueError('A valid GCP region is required to run a pipeline.')
    if not api_key:
      raise ValueError(
          'A valid GCP project API key is required to run a pipeline.'
          'Please refer to '
          'https://developers.google.com/places/web-service/get-api-key'
          'to obtain an API key.')
    if service_name and not endpoint:
      raise ValueError(
          'You cannot specify service_name without also specifying endpoint.')

    self._project_id = project_id
    self._region = region
    self._api_key = api_key
    self._endpoint = endpoint or DEFAULT_ENDPOINT
    # Removes '.googleapis.com' to get the service name if it's not specified.
    self._service_name = (
        service_name or self._endpoint[:-len('.googleapis.com')])

    # AIPlatformPipelines discovery service url pattern.
    self._discovery_url = ('https://{endpoint}/$discovery/'
                           'rest?labels={visibility_label}&version={version}'
                           '&key={api_key}').format(
                               endpoint=self._endpoint,
                               visibility_label=VISIBILITY_LABEL,
                               version=API_VERSION,
                               api_key=self._api_key)

  def _display_job_link(self, job_id: str):
    """Display an link to UI."""
    url = UI_PIPELINE_JOB_LINK_FORMAT.format(job_id, self._project_id)
    if _is_ipython():
      import IPython  # pylint: disable=g-import-not-at-top
      html = UI_LINK_HTML_FORMAT.format(url)
      IPython.display.display(IPython.display.HTML(html))
    else:
      print('See the Pipeline job here:', url)

  def _submit_job(self,
                  job_spec: Mapping[str, Any],
                  name: Optional[str] = None) -> str:
    """Submits a pipeline job to run on AIPlatformPipelines service.

    Args:
      job_spec: AIPlatformPipelines pipelineJob spec.
      name: User-specified name of this pipelineJob. If not provided, pipeline
        service will automatically generate a random numeric ID.

    Returns:
      Full AIPlatformPipelines job name.

    Raises:
      RuntimeError: If AIPlatformPipelines service returns unexpected response
      or empty job name.
    """

    api_client = discovery.build(
        self._service_name,
        API_VERSION,
        credentials=_get_gcp_credential(),
        cache_discovery=False,
        discoveryServiceUrl=self._discovery_url)

    # TODO(b/171925435): Remove the workaround once the discovery doc is fixed
    api_client._baseUrl = 'https://{}'.format(self._endpoint)  # pylint:disable=protected-access

    logging.info('Compiled JSON request: %s', json.dumps(job_spec))
    request = api_client.projects().locations().pipelineJobs().create(
        body=job_spec,
        pipelineJobId=name,
        parent='projects/%s/locations/%s' % (self._project_id, self._region))
    response = request.execute()
    logging.info('Received server response: %s', json.dumps(response))
    if not response or not response.get('name'):
      raise RuntimeError('Unexpected response received. Response: %s' %
                         json.dumps(response))
    logging.info('Execution triggered. Job name: %s', response['name'])
    job_id = _extract_job_id(response['name'])
    if job_id:
      self._display_job_link(job_id)
    return response

  def get_job(self, name: Optional[str] = None) -> Dict[str, Any]:
    """Gets an existing pipeline job on AIPlatformPipelines service.

    Args:
      name: The relative name of this pipelineJob. The full qualified name will
        generated according to the project ID and region specified for the
        client.

    Returns:
      The JSON-formatted response from service.
    """
    api_client = discovery.build(
        self._service_name,
        API_VERSION,
        credentials=_get_gcp_credential(),
        cache_discovery=False,
        discoveryServiceUrl=self._discovery_url)

    # TODO(b/171925435): Remove the workaround once the discovery doc is fixed
    api_client._baseUrl = 'https://{}'.format(self._endpoint)  # pylint:disable=protected-access
    full_name = _JOB_NAME_PATTERN.format(
        project_id=self._project_id, region=self._region, job_name=name)
    return api_client.projects().locations().pipelineJobs().get(
        name=full_name).execute()

  def _load_json(self, file_path: str) -> Dict[str, Any]:
    """Loads data from a JSON document.

    Args:
      file_path: The local file path of the JSON document.

    Returns:
      A deserialized Dict object representing the JSON document.

    Raises:
      ParseError: On JSON parsing problems.
    """

    with open(file_path) as f:
      return json.load(f)

  def create_run_from_job_spec(
      self,
      job_spec_path: str,
      name: Optional[str] = None,
      pipeline_root: Optional[str] = None,
      parameter_values: Optional[Mapping[str, Any]] = None) -> str:
    """Runs a pre-compiled pipeline job on AIPlatformPipelines service.

    Args:
      job_spec_path: The local file path of PipelineJob JSON.
      name: Optionally, the user can provide the name for the pipelineJob. Note
        this is not the full qualified resource name but the relative name. If
        not specified, pipeline name + timestamp will be used.
      pipeline_root: Optionally the user can override the pipeline root
        specified during the compile time.
      parameter_values: The mapping from runtime parameter names to its values.

    Returns:
      Full AIPlatformPipelines job name.

    Raises:
      ParseError: On JSON parsing problems.
      RuntimeError: If AIPlatformPipelines service returns unexpected response
      or empty job name.
    """
    data = self._load_json(job_spec_path)
    pipeline_name = data['pipelineSpec']['pipelineInfo']['name']
    name = name or '{pipeline_name}-{timestamp}'.format(
        pipeline_name=re.sub('[^-0-9a-z]+', '-',
                             pipeline_name.lower()).lstrip('-').rstrip('-'),
        timestamp=_get_current_time().strftime('%Y%m%d%H%M%S'))
    if not _VALID_NAME_PATTERN.match(name):
      raise ValueError(
          'Generated job name: {} is illegal as a uCAIP pipelines job name. '
          'Expecting a name following the regex pattern '
          '"[a-z][-a-z0-9]{{0,127}}"'.format(name))
    data['name'] = _JOB_NAME_PATTERN.format(
        project_id=self._project_id, region=self._region, job_name=name)
    # Duplicate name to display name for the latter will soon be deprecated
    # from our API spec.
    data['displayName'] = name

    pipeline_root = pipeline_root or data['runtimeConfig']['gcsOutputDirectory']
    if not pipeline_root:
      raise ValueError('Pipeline root must be specified, either during compile '
                       'time, or when calling the service.')

    # Merge the parameter values into the runtime config.
    runtime_config = runtime_config_builder.RuntimeConfigBuilder(
        pipeline_root=pipeline_root, parameter_values=parameter_values).build()

    data['runtimeConfig'] = runtime_config

    return self._submit_job(job_spec=data, name=name)

  def create_run_from_pipeline_spec(
      self,
      pipeline_spec_path: str,
      pipeline_root: str,
      name: Optional[str] = None,
      parameter_values: Optional[Mapping[str, Any]] = None) -> str:
    """Creates a pipeline job from pipeline spec, and runs it on AI Platform.

    Args:
      pipeline_spec_path: The local file path of PipelineSpec JSON.
      pipeline_root: The root of the pipeline outputs.
      name: Optionally, the user can provide the name for the pipelineJob. Note
        this is not the full qualified resource name but the relative name. If
        not specified, pipeline name + timestamp will be used.
      parameter_values: The mapping from runtime parameter names to its values.

    Returns:
      Full AIPlatformPipelines job name.

    Raises:
      ParseError: On JSON parsing problems.
      RuntimeError: If AIPlatformPipelines service returns unexpected response
      or empty job name.
    """
    pipeline_spec = self._load_json(pipeline_spec_path)

    runtime_config = runtime_config_builder.RuntimeConfigBuilder(
        pipeline_root=pipeline_root, parameter_values=parameter_values).build()

    name = name or '{pipeline_name}-{timestamp}'.format(
        pipeline_name=pipeline_spec['pipelineInfo']['name'],
        timestamp=_get_current_time().strftime('%Y%m%d%H%M%S'))
    if not _VALID_NAME_PATTERN.match(name):
      raise ValueError(
          'Generated job name: {} is illegal as a uCAIP pipelines job name. '
          'Expecting a name following the regex pattern '
          '"[a-z][-a-z0-9]{{0,127}}"'.format(name))
    job_name = _JOB_NAME_PATTERN.format(
        project_id=self._project_id, region=self._region, job_name=name)

    pipeline_job = {
        'name': job_name,
        # Duplicate name to display name for the latter will soon be deprecated
        # from our API spec.
        'displayName': name,
        'runtimeConfig': runtime_config,
        'pipelineSpec': pipeline_spec,
    }

    return self._submit_job(job_spec=pipeline_job, name=name)

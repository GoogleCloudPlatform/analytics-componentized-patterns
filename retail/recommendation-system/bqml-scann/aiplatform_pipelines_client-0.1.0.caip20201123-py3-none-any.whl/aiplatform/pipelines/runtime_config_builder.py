# Copyright 2020 Google LLC. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Builder for CAIP pipelines Pipeline level proto spec."""

from typing import Any, Mapping, Optional, Union


class RuntimeConfigBuilder(object):
  """CAIP pipelines RuntimeConfig builder.

  Constructs a RuntimeConfig spec with pipeline_root and parameter overrides.
  """

  def __init__(self,
               pipeline_root: str,
               parameter_values: Optional[Mapping[str, Any]] = None):
    """Creates a RuntimeConfigBuilder object.

    Args:
      pipeline_root: The root of the pipeline outputs.
      parameter_values: The mapping from runtime parameter names to its values.
    """
    self._pipeline_root = pipeline_root
    self._parameter_values = parameter_values or {}

  def build(self) -> Mapping[str, Any]:
    """Build a RuntimeConfig proto."""
    return {
        'gcsOutputDirectory': self._pipeline_root,
        'parameters': {
            k: _get_caip_value(v)
            for k, v in self._parameter_values.items()
            if v
        }
    }


def _get_caip_value(
    value: Union[int, float, str]) -> Optional[Mapping[str, Any]]:
  """Converts primitive values into CAIP pipeline Value proto message."""
  if value is None:
    return None

  result = {}
  if isinstance(value, int):
    result['intValue'] = value
  elif isinstance(value, float):
    result['doubleValue'] = value
  elif isinstance(value, str):
    result['stringValue'] = value
  else:
    raise TypeError('Got unknown type of value: {}'.format(value))

  return result

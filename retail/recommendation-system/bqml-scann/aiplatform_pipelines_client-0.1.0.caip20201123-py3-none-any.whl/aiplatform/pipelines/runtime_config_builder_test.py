# Copyright 2020 Google LLC. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Tests for google3.cloud.ml.pipelines.sdk.python.aiplatform_pipelines_client.aiplatform.pipelines.runtime_config_builder."""

import unittest

from aiplatform.pipelines import runtime_config_builder


class RuntimeConfigBuilderTest(unittest.TestCase):

  def testBuildRuntimeConfig(self):
    my_builder = runtime_config_builder.RuntimeConfigBuilder(
        pipeline_root='path/to/my/root',
        parameter_values={
            'string_param': 'test-string',
            'int_param': 42,
            'float_param': 3.14
        })
    actual_runtime_config = my_builder.build()

    expected_runtime_config = {
        'gcsOutputDirectory': 'path/to/my/root',
        'parameters': {
            'string_param': {
                'stringValue': 'test-string'
            },
            'int_param': {
                'intValue': 42
            },
            'float_param': {
                'doubleValue': 3.14
            },
        }
    }
    self.assertEqual(expected_runtime_config, actual_runtime_config)


if __name__ == '__main__':
  unittest.main()
